import { AnimatePresence, motion } from "framer-motion";
import { X, LifeBuoy } from "lucide-react";
import { useEffect } from "react";

const YOUTUBE_ID = "Ly0JJwwe-KM";

type Chapter = { time: string; label: string };

export function VideoModal({
  open,
  onClose,
  title,
  subtitle,
  chapters,
  steps,
  extraNote,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  chapters?: Chapter[];
  steps?: string[];
  extraNote?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-8"
        >
          <div
            onClick={onClose}
            className="absolute inset-0 bg-black/70 backdrop-blur-md"
          />
          <motion.div
            initial={{ y: 24, scale: 0.97, opacity: 0 }}
            animate={{ y: 0, scale: 1, opacity: 1 }}
            exit={{ y: 16, scale: 0.98, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.2, 0.7, 0.2, 1] }}
            className="relative z-10 w-full max-w-3xl overflow-hidden rounded-3xl border border-border bg-card shadow-2xl"
          >
            <button
              onClick={onClose}
              className="absolute right-4 top-4 z-20 grid h-8 w-8 place-items-center rounded-full border border-border bg-secondary/70 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              <X size={14} />
            </button>

            <div className="relative aspect-video w-full overflow-hidden bg-black">
              {open && (
                <iframe
                  src={`https://www.youtube.com/embed/${YOUTUBE_ID}?autoplay=1&rel=0&modestbranding=1`}
                  title={title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="absolute inset-0 h-full w-full border-0"
                />
              )}
            </div>

            <div className="border-t border-border p-6">
              <h3 className="text-lg font-semibold tracking-tight">{title}</h3>
              {subtitle && (
                <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
              )}

              {chapters && (
                <div className="mt-5">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">
                    Chapters
                  </div>
                  <ul className="mt-2 divide-y divide-border rounded-xl border border-border">
                    {chapters.map((c) => (
                      <li
                        key={c.time}
                        className="flex items-center justify-between px-3 py-2 text-sm transition-colors hover:bg-secondary/60"
                      >
                        <span className="text-foreground">{c.label}</span>
                        <span className="font-mono text-xs text-muted-foreground">{c.time}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {steps && (
                <ol className="mt-5 space-y-2">
                  {steps.map((s, i) => (
                    <li key={i} className="flex gap-3 text-sm text-muted-foreground">
                      <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border border-border bg-secondary text-[11px] font-medium text-foreground">
                        {i + 1}
                      </span>
                      {s}
                    </li>
                  ))}
                </ol>
              )}

              {extraNote && (
                <p className="mt-4 text-sm text-primary/80">{extraNote}</p>
              )}

              <a
                href="mailto:ali@upgrade-academy.com"
                className="mt-5 inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-primary"
              >
                <LifeBuoy size={12} /> Need help? Contact support
              </a>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
