import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Play,
  LifeBuoy,
  LayoutGrid,
  Tag,
  Users,
  Star,
  PanelLeftClose,
  PanelLeftOpen,
} from "lucide-react";
import { VideoModal } from "./VideoModal";

const NAV = [
  { label: "Templates", href: "#templates", icon: LayoutGrid },
  { label: "Categories", href: "#categories", icon: Tag },
  { label: "Community", href: "#community", icon: Users },
  { label: "Features", href: "#features", icon: Star },
];

export function SideNav({
  open,
  onToggle,
  onOpenDemo,
}: {
  open: boolean;
  onToggle: () => void;
  onOpenDemo: () => void;
}) {
  return (
    <>
      {/* Desktop side rail */}
      <div className="pointer-events-none fixed inset-y-4 left-4 z-50 hidden md:block">
        <AnimatePresence initial={false} mode="wait">
          {open ? (
            <motion.aside
              key="open"
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              transition={{ duration: 0.3, ease: [0.2, 0.7, 0.2, 1] }}
              className="pointer-events-auto flex h-full w-60 flex-col rounded-3xl border border-border bg-background/70 p-4 backdrop-blur-xl"
            >
              <div className="flex items-center justify-between">
                <a href="#top" className="flex items-center px-1 py-1">
                  <img src="/logo.png" alt="myporto" className="h-9 w-auto" />
                </a>
                <button
                  onClick={onToggle}
                  aria-label="Collapse sidebar"
                  className="grid h-8 w-8 place-items-center rounded-lg border border-border text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                >
                  <PanelLeftClose size={14} />
                </button>
              </div>

              <ul className="mt-6 flex flex-col gap-1.5">
                {NAV.map((item) => (
                  <li key={item.label}>
                    <a
                      href={item.href}
                      className="flex items-center gap-2.5 rounded-xl border border-border bg-transparent px-3 py-2 text-[13px] text-muted-foreground transition-colors hover:border-foreground/30 hover:text-foreground"
                    >
                      <item.icon size={14} className="opacity-70" />
                      {item.label}
                    </a>
                  </li>
                ))}
              </ul>

              <div className="mt-auto flex flex-col gap-2 pt-4">
                <button className="inline-flex items-center justify-center gap-1.5 rounded-full border border-border px-3 py-2 text-[13px] text-muted-foreground transition-colors hover:border-foreground/30 hover:text-foreground">
                  <LifeBuoy size={14} />
                  Support
                </button>
                <button
                  onClick={onOpenDemo}
                  className="inline-flex items-center justify-center gap-1.5 rounded-full border border-border bg-secondary/60 px-3 py-2 text-[13px] font-medium text-foreground transition-all hover:border-primary/40"
                >
                  <Play size={12} className="fill-primary text-primary" />
                  Watch Demo
                </button>
              </div>
            </motion.aside>
          ) : (
            <motion.aside
              key="closed"
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              transition={{ duration: 0.3, ease: [0.2, 0.7, 0.2, 1] }}
              className="pointer-events-auto flex h-full w-14 flex-col items-center rounded-3xl border border-border bg-background/70 p-2 backdrop-blur-xl"
            >
              <button
                onClick={onToggle}
                aria-label="Open sidebar"
                className="mt-1 grid h-9 w-9 place-items-center rounded-lg border border-border text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              >
                <PanelLeftOpen size={14} />
              </button>
              <ul className="mt-4 flex flex-col gap-1.5">
                {NAV.map((item) => (
                  <li key={item.label}>
                    <a
                      href={item.href}
                      aria-label={item.label}
                      title={item.label}
                      className="grid h-9 w-9 place-items-center rounded-lg border border-border text-muted-foreground transition-colors hover:border-foreground/30 hover:text-foreground"
                    >
                      <item.icon size={14} />
                    </a>
                  </li>
                ))}
              </ul>
              <div className="mt-auto flex flex-col gap-1.5 pb-1">
                <button
                  aria-label="Support"
                  title="Support"
                  className="grid h-9 w-9 place-items-center rounded-lg border border-border text-muted-foreground transition-colors hover:border-foreground/30 hover:text-foreground"
                >
                  <LifeBuoy size={14} />
                </button>
                <button
                  onClick={onOpenDemo}
                  aria-label="Watch Demo"
                  title="Watch Demo"
                  className="grid h-9 w-9 place-items-center rounded-lg border border-border text-foreground transition-colors hover:border-primary/40"
                >
                  <Play size={12} className="fill-primary text-primary" />
                </button>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>

      {/* Mobile top bar */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.2, 0.7, 0.2, 1] }}
        className="fixed inset-x-0 top-4 z-50 flex justify-center px-4 md:hidden"
      >
        <nav className="flex w-full max-w-2xl items-center justify-between rounded-full border border-border bg-background/70 px-3 py-2 backdrop-blur-xl">
          <a href="#top" className="flex items-center pl-2 pr-3">
            <img src="/logo.png" alt="myporto" className="h-8 w-auto" />
          </a>
          <button
            onClick={onOpenDemo}
            className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/60 px-3 py-1.5 text-[13px] font-medium text-foreground transition-all hover:border-primary/40"
          >
            <Play size={12} className="fill-primary text-primary" />
            Watch Demo
          </button>
        </nav>
      </motion.header>
    </>
  );
}

export function SideNavWithState() {
  const [open, setOpen] = useState(true);
  const [demoOpen, setDemoOpen] = useState(false);
  return (
    <>
      <SideNav
        open={open}
        onToggle={() => setOpen((v) => !v)}
        onOpenDemo={() => setDemoOpen(true)}
      />
      {/* Top-right Watch Demo CTA (desktop) */}
      <motion.div
        initial={{ y: -10, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="fixed right-6 top-6 z-50 hidden md:block"
      >
        <button
          onClick={() => setDemoOpen(true)}
          className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background/70 px-4 py-2 text-[13px] font-medium text-foreground backdrop-blur-xl transition-all hover:border-primary/40"
        >
          <Play size={12} className="fill-primary text-primary" />
          Watch Demo
        </button>
      </motion.div>

      <VideoModal
        open={demoOpen}
        onClose={() => setDemoOpen(false)}
        title="How mywebporto works"
        subtitle="Discover, preview, clone and customize premium portfolio templates."
      />

      {/* Spacer hint for layout shift on collapse */}
      <style>{`
        :root { --porto-sidebar-w: ${open ? "18rem" : "5rem"}; }
        @media (min-width: 768px) {
          .porto-shift { padding-left: var(--porto-sidebar-w); transition: padding-left .3s ease; }
        }
      `}</style>
    </>
  );
}