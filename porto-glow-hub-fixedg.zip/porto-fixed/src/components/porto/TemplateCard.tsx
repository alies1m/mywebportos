import { useState } from "react";
import { motion } from "framer-motion";
import { Heart, ExternalLink, Download, BookOpen } from "lucide-react";
import type { Template } from "./templates";
import { TemplatePreview } from "./TemplatePreview";

export function TemplateCard({
  template,
  onOpen,
}: {
  template: Template;
  onOpen: (t: Template) => void;
}) {
  const [liked, setLiked] = useState(false);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, ease: [0.2, 0.7, 0.2, 1] }}
      className="porto-card porto-scroll-on-hover group relative cursor-pointer overflow-hidden"
      onClick={() => onOpen(template)}
    >
      {/* Preview */}
      <div className="relative aspect-video w-full overflow-hidden rounded-t-[23px] border-b border-border">
        <TemplatePreview template={template} />

        {/* Like */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setLiked((v) => !v);
          }}
          className="absolute right-3 top-3 z-20 grid h-8 w-8 place-items-center rounded-full border border-white/10 bg-black/40 text-white/80 backdrop-blur-md transition-all hover:scale-110 hover:bg-black/60"
          aria-label="Save"
        >
          <Heart
            size={14}
            className={liked ? "fill-primary text-primary" : ""}
          />
        </button>

        {/* Badge */}
        {template.badge && (
          <div className="absolute left-3 top-3 z-20 rounded-full border border-white/15 bg-black/50 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-white/90 backdrop-blur-md">
            {template.badge}
          </div>
        )}

        {/* Hover actions */}
        <div className="pointer-events-none absolute inset-x-3 bottom-3 z-20 flex translate-y-2 gap-2 opacity-0 transition-all duration-500 group-hover:pointer-events-auto group-hover:translate-y-0 group-hover:opacity-100">
          <a
            href={template.url}
            target="_blank"
            rel="noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-full border border-white/10 bg-black/60 px-3 py-1.5 text-[11px] font-medium text-white backdrop-blur-md transition-colors hover:bg-black/80"
          >
            <ExternalLink size={12} /> View
          </a>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpen(template);
            }}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-full bg-primary px-3 py-1.5 text-[11px] font-semibold text-primary-foreground transition-transform hover:scale-[1.02]"
          >
            <Download size={12} /> Clone
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpen(template);
            }}
            className="grid h-7 w-9 place-items-center rounded-full border border-white/10 bg-black/60 text-white backdrop-blur-md transition-colors hover:bg-black/80"
            aria-label="How to clone"
          >
            <BookOpen size={12} />
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-[15px] font-semibold tracking-tight text-foreground">
              {template.name}
            </h3>
            <p className="mt-1 line-clamp-1 text-[13px] text-muted-foreground">
              {template.description}
            </p>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            {template.tags.slice(0, 2).map((tag) => (
              <span
                key={tag}
                className="rounded-full border border-border bg-secondary/60 px-2 py-0.5 text-[10px] text-muted-foreground"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between border-t border-border pt-3">
          <div className="flex items-center gap-2">
            <span
              className="grid h-6 w-6 place-items-center rounded-full text-[10px] font-semibold text-white"
              style={{ background: `linear-gradient(135deg, ${template.accent}, #111)` }}
            >
              {template.creator.initials}
            </span>
            <span className="text-[12px] text-muted-foreground">
              by <span className="text-foreground">{template.creator.name}</span>
            </span>
          </div>
          <span className="text-[11px] text-muted-foreground">{template.category}</span>
        </div>
      </div>
    </motion.div>
  );
}