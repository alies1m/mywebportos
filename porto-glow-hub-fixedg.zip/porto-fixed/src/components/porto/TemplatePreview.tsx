import type { Template } from "./templates";

/** Shows a real screenshot if available, otherwise a stylized fake preview. */
export function TemplatePreview({ template }: { template: Template }) {
  if (template.previewImage) {
    return (
      <div className="absolute inset-0 flex items-start justify-center overflow-hidden bg-[#0a0a14]">
        <img
          src={template.previewImage}
          alt={template.name}
          className="w-full h-auto"
        />
      </div>
    );
  }

  return (
    <div
      className="absolute inset-0 overflow-hidden"
      style={{ background: template.gradient }}
    >
      {/* grid + glow */}
      <div
        className="absolute inset-0 opacity-40"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(255,255,255,.04) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,.04) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />
      <div
        className="absolute -left-10 top-1/3 h-40 w-40 rounded-full blur-3xl"
        style={{ background: template.accent, opacity: 0.25 }}
      />

      {/* "Browser" chrome */}
      <div className="relative z-10 flex items-center gap-1.5 px-3 py-2">
        <span className="h-1.5 w-1.5 rounded-full bg-white/30" />
        <span className="h-1.5 w-1.5 rounded-full bg-white/30" />
        <span className="h-1.5 w-1.5 rounded-full bg-white/30" />
        <span className="ml-2 truncate text-[9px] text-white/40">
          {template.id}.myporto.app
        </span>
      </div>

      {/* Scrollable fake page content */}
      <div className="porto-scrollable relative z-10 space-y-3 px-4 pb-4">
        <div className="space-y-1.5 pt-2">
          <div className="h-2 w-3/5 rounded-full bg-white/80" />
          <div className="h-2 w-2/5 rounded-full bg-white/30" />
        </div>
        <div className="h-16 rounded-lg border border-white/10 bg-white/5" />
        <div className="grid grid-cols-3 gap-1.5">
          <div className="h-10 rounded-md bg-white/10" />
          <div className="h-10 rounded-md bg-white/10" />
          <div className="h-10 rounded-md bg-white/10" />
        </div>
        <div className="space-y-1">
          <div className="h-1.5 w-full rounded-full bg-white/15" />
          <div className="h-1.5 w-11/12 rounded-full bg-white/15" />
          <div className="h-1.5 w-9/12 rounded-full bg-white/15" />
        </div>
        <div className="h-20 rounded-lg border border-white/10 bg-white/5" />
        <div className="grid grid-cols-2 gap-1.5">
          <div className="h-14 rounded-md bg-white/10" />
          <div className="h-14 rounded-md bg-white/10" />
        </div>
        <div className="space-y-1">
          <div className="h-1.5 w-full rounded-full bg-white/10" />
          <div className="h-1.5 w-8/12 rounded-full bg-white/10" />
        </div>
        <div className="h-14 rounded-lg border border-white/10 bg-white/5" />
        <div className="grid grid-cols-3 gap-1.5">
          <div className="h-8 rounded-md bg-white/10" />
          <div className="h-8 rounded-md bg-white/10" />
          <div className="h-8 rounded-md bg-white/10" />
        </div>
      </div>
    </div>
  );
}
