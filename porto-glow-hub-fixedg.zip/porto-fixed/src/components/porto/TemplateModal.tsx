import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X, ExternalLink, Download, PlayCircle } from "lucide-react";
import type { Template } from "./templates";
import { TemplatePreview } from "./TemplatePreview";
import { VideoModal } from "./VideoModal";

export function TemplateModal({
  template,
  onClose,
}: {
  template: Template | null;
  onClose: () => void;
}) {
  const [tutorialOpen, setTutorialOpen] = useState(false);

  return (
    <>
      <AnimatePresence>
        {template && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[55] flex items-center justify-center p-4 sm:p-8"
          >
            <div onClick={onClose} className="absolute inset-0 bg-black/70 backdrop-blur-md" />
            <motion.div
              initial={{ y: 30, scale: 0.97, opacity: 0 }}
              animate={{ y: 0, scale: 1, opacity: 1 }}
              exit={{ y: 20, scale: 0.98, opacity: 0 }}
              transition={{ duration: 0.35, ease: [0.2, 0.7, 0.2, 1] }}
              className="relative z-10 w-full max-w-4xl overflow-hidden rounded-3xl border border-border bg-card shadow-2xl"
            >
              <button
                onClick={onClose}
                className="absolute right-4 top-4 z-20 grid h-9 w-9 place-items-center rounded-full border border-border bg-secondary/70 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              >
                <X size={15} />
              </button>

              <div className="relative aspect-[16/9] w-full overflow-hidden border-b border-border">
                <TemplatePreview template={template} />
              </div>

              <div className="grid gap-6 p-7 md:grid-cols-[1fr_auto] md:items-end">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="rounded-full border border-border bg-secondary/60 px-2 py-0.5 text-[11px] uppercase tracking-wider text-muted-foreground">
                      {template.category}
                    </span>
                    {template.badge && (
                      <span className="rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 text-[11px] font-medium text-primary">
                        {template.badge}
                      </span>
                    )}
                  </div>
                  <h2 className="mt-3 text-3xl font-semibold tracking-tight">
                    {template.name}
                  </h2>
                  <p className="mt-2 max-w-xl text-sm text-muted-foreground">
                    {template.description} Designed for modern creators and built to launch in minutes.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {template.stack.map((s) => (
                      <span
                        key={s}
                        className="rounded-full border border-border bg-secondary/60 px-2.5 py-1 text-[11px] text-foreground"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 md:flex-col md:items-stretch">
                  <a
                    href={template.url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 rounded-full border border-border bg-secondary/60 px-4 py-2 text-[13px] font-medium text-foreground transition-colors hover:bg-secondary"
                  >
                    <ExternalLink size={14} /> View Website
                  </a>
                  <a
                    href={template.url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 rounded-full bg-primary px-4 py-2 text-[13px] font-semibold text-primary-foreground transition-transform hover:scale-[1.02] porto-glow"
                  >
                    <Download size={14} /> Clone Template
                  </a>
                  <button
                    onClick={() => setTutorialOpen(true)}
                    className="inline-flex items-center justify-center gap-1.5 rounded-full border border-border bg-transparent px-4 py-2 text-[13px] font-medium text-foreground transition-colors hover:bg-secondary"
                  >
                    <PlayCircle size={14} /> Watch Clone Tutorial
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <VideoModal
        open={tutorialOpen}
        onClose={() => setTutorialOpen(false)}
        title={`How to clone ${template?.name ?? "this template"}`}
        subtitle="Replace the current portfolio content with:"
        steps={[
          "[Your Name]",
          "[Your Major]",
          "[Your Experience]",
        ]}
        extraNote="You can also upload your CV directly to personalize your portfolio even faster."
      />
    </>
  );
}
