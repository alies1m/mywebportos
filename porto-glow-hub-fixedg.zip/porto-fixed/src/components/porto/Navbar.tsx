import { useState } from "react";
import { motion } from "framer-motion";
import { Play, LifeBuoy, Sparkles } from "lucide-react";
import { VideoModal } from "./VideoModal";

const NAV = ["Templates", "Categories", "Community", "Features", "Pricing"];

export function Navbar() {
  const [demoOpen, setDemoOpen] = useState(false);
  return (
    <>
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.2, 0.7, 0.2, 1] }}
        className="fixed inset-x-0 top-4 z-50 flex justify-center px-4"
      >
        <nav className="porto-glass flex w-full max-w-5xl items-center justify-between rounded-full border border-border px-3 py-2 shadow-[0_10px_40px_-20px_rgba(0,0,0,.8)]">
          <a href="#top" className="flex items-center gap-2 pl-2 pr-3">
            <span className="grid h-7 w-7 place-items-center rounded-full bg-primary/15 text-primary">
              <Sparkles size={14} />
            </span>
            <span className="text-sm font-semibold tracking-tight">My Porto</span>
          </a>

          <ul className="hidden items-center gap-1 md:flex">
            {NAV.map((item) => (
              <li key={item}>
                <a
                  href={`#${item.toLowerCase()}`}
                  className="rounded-full px-3 py-1.5 text-[13px] text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                >
                  {item}
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-1.5">
            <button className="hidden items-center gap-1.5 rounded-full px-3 py-1.5 text-[13px] text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground sm:inline-flex">
              <LifeBuoy size={14} />
              Support
            </button>
            <button
              onClick={() => setDemoOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/60 px-3 py-1.5 text-[13px] font-medium text-foreground transition-all hover:border-primary/40 hover:bg-secondary"
            >
              <Play size={12} className="fill-primary text-primary" />
              Watch Demo
            </button>
          </div>
        </nav>
      </motion.header>
      <VideoModal
        open={demoOpen}
        onClose={() => setDemoOpen(false)}
        title="How mywebporto works"
        subtitle="Discover, preview, clone and customize premium portfolio templates."
      />
    </>
  );
}