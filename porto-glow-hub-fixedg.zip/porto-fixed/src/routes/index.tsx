import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Sparkles,
  Users,
  Mail,
  Linkedin,
} from "lucide-react";

// Sparkles kept for internal use in sections other than logo
import { SideNavWithState } from "@/components/porto/SideNav";
import { TemplateCard } from "@/components/porto/TemplateCard";
import { TemplateModal } from "@/components/porto/TemplateModal";
import { CATEGORIES, TEMPLATES, type Template } from "@/components/porto/templates";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  const [category, setCategory] = useState("All");
  const [active, setActive] = useState<Template | null>(null);

  const filtered = useMemo(() => {
    return TEMPLATES.filter((t) => {
      const matchCat =
        category === "All" ||
        t.category.toLowerCase().includes(category.toLowerCase()) ||
        t.tags.some((tag) => tag.toLowerCase().includes(category.toLowerCase())) ||
        t.stack.some((s) => s.toLowerCase().includes(category.toLowerCase()));
      return matchCat;
    });
  }, [category]);

  return (
    <div id="top" className="relative min-h-screen porto-bg text-foreground">
      {/* Ambient layers */}
      <div className="pointer-events-none absolute inset-0 porto-grid" />
      <div className="pointer-events-none absolute inset-0 opacity-[0.35] porto-noise" />

      <SideNavWithState />

      {/* HERO — left aligned */}
      <section className="relative pt-32 pb-10 sm:pt-36 porto-shift">
        <div className="mx-auto max-w-7xl px-4">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.05 }}
            className="porto-display max-w-3xl text-[34px] font-semibold leading-[1.05] sm:text-[48px] lg:text-[60px]"
          >
            Discover portfolio
            <br className="hidden sm:block" /> templates creators actually use.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="mt-5 max-w-xl text-[14px] leading-relaxed text-muted-foreground"
          >
            Browse ready-made portfolio templates built for Vercel, Lovable, and AI-generated
            websites. Clone, customize, and launch instantly.
          </motion.p>
        </div>
      </section>

      {/* TEMPLATES GRID */}
      <section id="templates" className="relative px-4 pb-24 pt-8 porto-shift">
        <div className="mx-auto max-w-7xl">
          {/* Categories */}
          <div id="categories" className="mb-8 flex flex-wrap gap-2">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={`rounded-full border px-3.5 py-1.5 text-[12.5px] transition-all ${
                  category === c
                    ? "border-primary/40 bg-primary/15 text-primary porto-glow"
                    : "border-border bg-secondary/40 text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="mb-6 flex items-end justify-between">
            <div>
              <h2 className="text-xl font-semibold tracking-tight sm:text-2xl">
                Featured templates
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Handpicked, production-ready portfolio templates.
              </p>
            </div>
            <span className="hidden text-xs text-muted-foreground sm:block">
              {filtered.length} of {TEMPLATES.length}
            </span>
          </div>

          {filtered.length === 0 ? (
            <div className="grid place-items-center rounded-3xl border border-dashed border-border p-16 text-center text-muted-foreground">
              No templates match your filters yet.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
              {filtered.map((t) => (
                <TemplateCard key={t.id} template={t} onOpen={setActive} />
              ))}
            </div>
          )}

          <div className="mt-10 flex justify-center">
            <button className="rounded-full border border-border bg-secondary/40 px-5 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground">
              Load more
            </button>
          </div>
        </div>
      </section>

      {/* TRENDING */}
      <div className="porto-shift"><Trending onOpen={setActive} /></div>

      {/* COMMUNITY */}
      <div className="porto-shift"><Community /></div>

      {/* NEED MORE */}
      <div className="porto-shift"><NeedMore /></div>

      {/* FOOTER */}
      <div className="porto-shift"><Footer /></div>

      <TemplateModal template={active} onClose={() => setActive(null)} />
    </div>
  );
}

function Trending({ onOpen }: { onOpen: (t: Template) => void }) {
  const trending = TEMPLATES.filter((t) => t.badge).slice(0, 3);
  return (
    <section id="features" className="relative px-4 pb-24">
      <div className="mx-auto max-w-7xl">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/40 px-2.5 py-1 text-[11px] text-muted-foreground">
              <Sparkles size={11} className="text-primary" /> Trending this week
            </span>
            <h2 className="mt-3 text-xl font-semibold tracking-tight sm:text-2xl">
              Most cloned by the community
            </h2>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {trending.map((t) => (
            <TemplateCard key={t.id} template={t} onOpen={onOpen} />
          ))}
        </div>
      </div>
    </section>
  );
}

function Community() {
  const creators = [
    { n: "AR", c: "#e5e7eb" },
    { n: "MK", c: "#a1a1aa" },
    { n: "SH", c: "#d4d4d8" },
    { n: "DK", c: "#71717a" },
    { n: "YS", c: "#ffffff" },
  ];
  const stats = [
    { v: "16", l: "Portfolio templates" },
    { v: "80+", l: "Creators using them" },
    { v: "340+", l: "Clones to date" },
    { v: "5.0★", l: "Community rating" },
  ];
  return (
    <section id="community" className="relative px-4 pb-24">
      <div className="mx-auto max-w-7xl rounded-3xl border border-border porto-glass p-8 sm:p-12">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/40 px-2.5 py-1 text-[11px] text-muted-foreground">
              <Users size={11} className="text-primary" /> Community
            </span>
            <h2 className="porto-display mt-4 text-3xl font-semibold tracking-tight sm:text-4xl">
              A quiet community of <span className="porto-serif text-primary">builders</span>.
            </h2>
            <p className="mt-3 max-w-md text-sm text-muted-foreground">
              Creators ship together — share remixes, request templates, and get feedback from
              designers and engineers who actually build.
            </p>

            <div className="mt-6 flex items-center -space-x-2">
              {creators.map((c, i) => (
                <span
                  key={i}
                  className="grid h-8 w-8 place-items-center rounded-full border border-background text-[10px] font-semibold text-black"
                  style={{ background: c.c }}
                >
                  {c.n}
                </span>
              ))}
              <span className="ml-3 text-xs text-muted-foreground">+75 creators</span>
            </div>

            <a
              href="https://www.linkedin.com/in/thealiesam"
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02] porto-glow"
            >
              <Linkedin size={14} /> Follow us on LinkedIn
            </a>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {stats.map((s) => (
              <div
                key={s.l}
                className="rounded-2xl border border-border bg-card/60 p-5"
              >
                <div className="porto-display text-3xl font-semibold tracking-tight">
                  {s.v}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function NeedMore() {
  return (
    <section id="request" className="relative px-4 pb-24">
      <div className="mx-auto max-w-7xl">
        <div className="relative overflow-hidden rounded-3xl border border-border porto-glass p-10 porto-glow">
          <div
            className="pointer-events-none absolute -inset-px rounded-3xl opacity-30"
            style={{
              background:
                "radial-gradient(60% 60% at 50% 0%, rgba(34,197,94,.2), transparent 70%)",
            }}
          />
          <span className="relative inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/40 px-2.5 py-1 text-[11px] text-muted-foreground">
            <Mail size={11} className="text-primary" /> Request
          </span>
          <h2 className="porto-display relative mt-4 text-3xl font-semibold tracking-tight sm:text-4xl">
            Want more templates or improvements?
          </h2>
          <p className="relative mt-3 max-w-md text-sm text-muted-foreground">
            Send your ideas, suggestions, and template requests directly to us.
          </p>
          <a
            href="mailto:ali@upgrade-academy.com"
            className="relative mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02]"
          >
            <span>ali@upgrade-academy.com</span>
            <ArrowRight size={14} />
          </a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="relative border-t border-border px-4 py-12">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between">
          <div className="max-w-xs">
            <div className="flex items-center">
              <img src="/logo.png" alt="myporto" className="h-8 w-auto" />
            </div>
            <p className="mt-3 text-sm text-muted-foreground">
              Premium portfolio templates built for modern creators.
            </p>
            <div className="mt-4 flex gap-2">
              <a
                className="grid h-8 w-8 place-items-center rounded-full border border-border text-muted-foreground transition-colors hover:text-foreground"
                href="https://www.linkedin.com/in/thealiesam"
                target="_blank"
                rel="noreferrer"
              >
                <Linkedin size={14} />
              </a>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-10 text-sm sm:grid-cols-3">
            {[
              { h: "Product", l: ["Templates", "Categories", "Community"] },
              { h: "Support", l: ["Support", "Watch Demo", "Contact"] },
              { h: "Legal", l: ["Terms", "Privacy"] },
            ].map((col) => (
              <div key={col.h}>
                <div className="text-xs uppercase tracking-wider text-muted-foreground/70">
                  {col.h}
                </div>
                <ul className="mt-3 space-y-2">
                  {col.l.map((i) => (
                    <li key={i}>
                      <a
                        href="#"
                        className="text-foreground/80 transition-colors hover:text-primary"
                      >
                        {i}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-10 border-t border-border pt-6 text-center text-xs text-muted-foreground">
          © All rights reserved for Ali &amp; MoKing 2026
        </div>
      </div>
    </footer>
  );
}
